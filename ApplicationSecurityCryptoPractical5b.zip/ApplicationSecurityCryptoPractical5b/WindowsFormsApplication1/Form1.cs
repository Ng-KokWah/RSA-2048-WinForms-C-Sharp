﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        byte[] Key;
        byte[] IV;
        String publicKeyRSA;
        String privateKeyRSA;
        RSAParameters privateParams;
        

        public Form1()
        {
            InitializeComponent();
        }

        private void btnGenKey_Click(object sender, EventArgs e)
        {
            /*
            SymmetricAlgorithm sa = new RijndaelManaged(); 
            sa.GenerateKey();
            Key = sa.Key;
            IV = sa.IV;

            txtKey.Text = BitConverter.ToString(Key); 
            btnEncrypt.Enabled = true; 
            txtPlain.Enabled = true; 
             * */
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(2048);
            publicKeyRSA = rsa.ToXmlString(false);
            privateKeyRSA = rsa.ToXmlString(true);

            txtPublicKey.Text = "Public Key: " + publicKeyRSA;
            txtPrivateKey.Text = "Private Key: " + privateKeyRSA;

            btnEncrypt.Enabled = true;
            txtPlain.Enabled = true; 
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            /*
            SymmetricAlgorithm sa = new RijndaelManaged(); 
            sa.Key = Key; 
            sa.IV = IV;

            ICryptoTransform cryptTransform = sa.CreateEncryptor();
             * */
            byte[] plainBytesRSA = Encoding.UTF8.GetBytes(txtPlain.Text);
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(publicKeyRSA);

            byte[] cipherBytesRSA = rsa.Encrypt(plainBytesRSA, false); //use public key

            txtCipher.Text = Convert.ToBase64String(cipherBytesRSA); 
            btnDecrypt.Enabled = true; 
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            /*SymmetricAlgorithm sa = new RijndaelManaged(); 
            sa.Key = Key; 
            sa.IV = IV;

            ICryptoTransform cryptTransform = sa.CreateDecryptor(); */
            byte[] cipherText = Convert.FromBase64String(txtCipher.Text);

            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(privateKeyRSA);

            byte[] plainBytes = rsa.Decrypt(cipherText, false);

            txtOrg.Text = Encoding.UTF8.GetString(plainBytes); 
        }

    }
}
